<?php

namespace Wolosky;

use Illuminate\Database\Eloquent\Model;

class SalaryType extends Model {

    protected $fillable = [
        'description'
    ];

}
