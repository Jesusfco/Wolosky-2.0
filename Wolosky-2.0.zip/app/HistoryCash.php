<?php

namespace Wolosky;

use Illuminate\Database\Eloquent\Model;

class HistoryCash extends Model
{
    //
}
